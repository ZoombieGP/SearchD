package com.jalasoft.search.model;

public class File extends Asset {
    public File(){
        super();
    }


}
