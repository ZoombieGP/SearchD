package com.jalasoft.search.model;
import java.io.*;
import java.io.File;

public class Search {

      private void searchByPath(File dir){
        File listFile[] = dir.listFiles();
        if(listFile != null){
            for (int i = 0; i< listFile.length; i++){
                if(listFile[i].isDirectory()){
                    searchByPath(listFile[i]);
                }else{
                    System.out.println(listFile[i].getAbsolutePath());
                }
            }
        }
    }

    private  void searchByPathAndName(File dir, String fileName){
        File listFile[] = dir.listFiles();
        if(listFile != null){
            for (int i = 0; i< listFile.length; i++){
                if(listFile[i].isDirectory()){
                    if(listFile[i].getName().contains(fileName)){
                        System.out.println(listFile[i].getAbsolutePath());
                    }
                    searchByPathAndName(listFile[i], fileName);
                }else{
                    if(listFile[i].getName().contains(fileName)){
                        System.out.println(listFile[i].getAbsolutePath());
                    }
                }
            }
        }
    }

    private  void searchByPathAndContens(File dir, String contens){
        File listFile[] = dir.listFiles();
        if(listFile != null){
            for (int i = 0; i< listFile.length; i++){
                if(listFile[i].isDirectory()){
                    searchByPathAndContens(listFile[i], contens);
                }else{
                    try {
                        final BufferedReader reader = new BufferedReader(
                                new FileReader(listFile[i])
                        );
                        String line = "";
                        while((line = reader.readLine())!= null){
                            if(line.indexOf(contens)!= -1){
                                System.out.println(listFile[i].getAbsolutePath());
                                System.out.println("se encontro la palabra "+ line);
                            }
                        }
                        reader.close();
                    } catch (FileNotFoundException e) {e.printStackTrace();
                    } catch (IOException e) {e.printStackTrace();}
                }
            }
        }
    }

    public void getResults() {
        this.searchByPathAndContens(new File("C:/test"), "ROM");
    }
}
